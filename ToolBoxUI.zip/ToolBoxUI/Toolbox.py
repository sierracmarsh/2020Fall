import maya.cmds as cmds
import RandomUI2 as nameUI
import RenameObjs 

class ToolBox():
    def _init_(self):
        self.my_window = 'ToolUI'

    def Window(self):
        self.my_window = cmds.window(title="ToolUI",
                                      widthHeight=(400,100))
        self.column = cmds.columnLayout(parent=self.my_window,
                                            adjustableColumn=True)

        cmds.button(parent=self.column, label='Randomizer', command=lambda *x: self.call_nameUI())
        cmds.button(parent=self.column, label='Rename List', command=lambda *x: self.RenameObjs())


        cmds.showWindow(self.my_window)

    def delete(self):
        if cmds.window(self.my_window, exists=True):
            cmds.deleteUI(self.my_window)

    def RenameUI(self):
        nameUI = renamer.Renamer.createWindow()
        nameUI()


    def RenameOBJUI(self):
        randUI = randGen.RandomGeneratorUI.createWindow()
        randUI()
