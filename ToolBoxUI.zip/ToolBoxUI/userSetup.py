import sys
sys.path.append('C:\Users\dallon\Documents\maya\2019\MyScripts')